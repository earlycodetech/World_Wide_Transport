@extends('layouts.app')
@section('sam')
    <h1> Hello World </h1>
    <h2>Hello People</h2>
@endsection
