<h1> Product: {{ $name }} </h1>
<h1> Price:  {{ $price }}</h1>