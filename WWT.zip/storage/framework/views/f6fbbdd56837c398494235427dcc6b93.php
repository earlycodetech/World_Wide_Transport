<?php $__env->startSection('content'); ?>
    <section style="background-image: url(<?php echo e(asset('images/anita.jpg')); ?>);">
        <div class="container">
            <img src="<?php echo e(URL('images/anita.jpg')); ?>" height="200" alt="" class="w-100 mb-3">

            <img src="<?php echo e(asset('images/anita.jpg')); ?>" width="100" alt="">
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\WWT\resources\views/welcome.blade.php ENDPATH**/ ?>