<h1> Product: <?php echo e($name); ?> </h1>
<h1> Price:  <?php echo e($price); ?></h1><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\Tutorial\resources\views/product.blade.php ENDPATH**/ ?>