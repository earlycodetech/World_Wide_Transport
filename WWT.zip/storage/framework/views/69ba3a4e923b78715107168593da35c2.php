
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container my-5">
            <div class="card mx-auto w-75 bg-white">
                <div class="card-header bg-white">
                    Add a New Location
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('locations.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <label for="" class="form-label">Departure Location</label>
                        <input type="text" name="departure" class="form-control mb-3">

                        <?php $__errorArgs = ['departure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="fw-bold text-danger d-block text-end"> <?php echo e($message); ?> </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <label for="" class="form-label">Destination Location</label>
                        <input type="text" name="destination" class="form-control mb-3">

                        <label for="" class="form-label">Price</label>
                        <input type="number" name="price" class="form-control mb-3">

                        <label for="" class="form-label">Passengers</label>
                        <input type="number" name="passengers" min="10" max="40" class="form-control mb-3">

                        <button class="btn btn-primary"> Save </button>
           
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\Tutorial\resources\views/locations/create.blade.php ENDPATH**/ ?>