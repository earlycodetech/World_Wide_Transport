<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger position-fixed alert-dismissible fade show" role="alert"
            style="top: 30%; right: 20px; z-index: 9999;">
            <strong> <?php echo e($error); ?> </strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success position-fixed alert-dismissible fade show" role="alert"
        style="top: 30%; right: 20px; z-index: 9999;">
        <strong> <?php echo e($message); ?> </strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\Tutorial\resources\views/partials/errors.blade.php ENDPATH**/ ?>