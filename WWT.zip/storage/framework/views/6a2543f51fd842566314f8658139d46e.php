
<?php $__env->startSection('sam'); ?>
    <h1> Hello World </h1>
    <h2>Hello People</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\Tutorial\resources\views/class.blade.php ENDPATH**/ ?>