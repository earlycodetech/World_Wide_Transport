
<?php $__env->startSection('content'); ?>
    <section style="background-color: #eee;">
        <div class="container py-5">
      
            <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('user.profile.update')); ?>" class="row">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <div class="col-lg-4">
                    <div class="card mb-4">
                        <div class="card-body text-center">
                            <img src="<?php echo e(asset(Auth::user()->picture)); ?>"
                                alt="avatar" class="rounded-circle img-fluid" style="width: 150px; height: 150px;">
                            <h5 class="my-3"> <?php echo e(Auth::user()->name); ?> </h5>
                            <p class="text-muted mb-1"> <?php echo e(Auth::user()->email); ?> </p>
                            <p class="text-muted mb-4"><?php echo e(Auth::user()->address); ?></p>
                            <div class="d-flex justify-content-center mb-2">
                               <input type="file" name="picture" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-8 my-3">

                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0">Full Name</p>
                                </div>
                                <div class="col-sm-9">
                                    <input type="text" name="name" value="<?php echo e(Auth::user()->name); ?>" class="form-control bg-white">
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0">Email</p>
                                </div>
                                <div class="col-sm-9">
                                    <input type="text" disabled  value="<?php echo e(Auth::user()->email); ?>" class="form-control bg-white">
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0">Phone</p>
                                </div>
                                <div class="col-sm-9">
                                    <input type="text" name="phone" value="<?php echo e(Auth::user()->phone_number); ?>" class="form-control bg-white">
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0"> Next of Kin </p>
                                </div>
                                <div class="col-sm-9">
                                    <input type="text" name="next_of_kin" value="<?php echo e(Auth::user()->nok); ?>" class="form-control bg-white">
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0"> Next of Kin Phone Number </p>
                                </div>
                                <div class="col-sm-9">
                                    <input type="text" name="next_of_kin_phone_number" value="<?php echo e(Auth::user()->nok_phone); ?>" class="form-control bg-white">
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0">Address</p>
                                </div>
                                <div class="col-sm-9">
                                    <input type="text" name="address" value="<?php echo e(Auth::user()->address); ?>" class="form-control bg-white">
                                </div>
                            </div>

                            <button class="btn btn-primary"> Update </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\WWT\resources\views/profile.blade.php ENDPATH**/ ?>