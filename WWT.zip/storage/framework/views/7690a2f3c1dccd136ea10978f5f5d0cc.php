
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container my-5">
            <div class="card bg-white border-0 shadow">
                <div class="card-header bg-white">
                    All Locations
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered table-dark">
                        <thead>
                            <tr>
                                <th scope="row"> Departure </th>
                                <th scope="row"> Destination </th>
                                <th scope="row"> Price </th>
                                <th scope="row"> N<sub>o</sub> Passengers </th>
                                <th>
                                    ...
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td> <?php echo e($loc['departure']); ?> </td>
                                    <td> <?php echo e($loc['destination']); ?> </td>
                                    <td> &#8358; <?php echo e(number_format($loc['price'],2)); ?> </td>
                                    <td> <?php echo e($loc['passengers']); ?> </td>
                                    <td class="d-flex gap-2">
                                        <a href="<?php echo e(route('locations.edit', ['location'=> $loc->id])); ?>" class="btn btn-primary"> Edit </a>

                                        <form 
                                            onsubmit="return confirm('Are you sure?')"
                                            action="<?php echo e(route('locations.destroy', ['location'=> $loc['id']])); ?>" 
                                            method="post">

                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger"> Delete </button>
                                        </form>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="p-4 fs-2 text-center text-danger">
                                        No Location Found 
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>


                    <div class="p-3">
                        <?php echo $locations->links('pagination::bootstrap-5'); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\WWT\resources\views/locations/index.blade.php ENDPATH**/ ?>